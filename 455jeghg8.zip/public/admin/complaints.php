<?php
session_start();
?>

<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>College Complaint Management System</title>

<link rel="stylesheet" href="css/style.css">

</head>

<body>

<div class="container">

<h1>College Complaint Management System</h1>

<p>Welcome to the College Complaint Management System</p>

<a href="login.php">Login</a>

<br><br>

<a href="register.php">Register</a>

</div>

</body>
</html>