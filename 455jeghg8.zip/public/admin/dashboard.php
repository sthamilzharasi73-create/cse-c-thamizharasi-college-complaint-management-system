<?php
session_start();

include "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "admin") {
    header("Location: ../login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>

<h1>Admin Dashboard</h1>

<p>Welcome Admin</p>

<a href="complaints.php">View Complaints</a>

<br><br>

<a href="../logout.php">Logout</a>

</body>
</html>