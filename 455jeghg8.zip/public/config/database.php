<?php

$host = "db01.dbhost.dev";
$port = 5051;
$username = "user_44zxqnqhb";
$password = "p44zxqnqhb";
$database = "db_44zxqnqhb";

try {
    $conn = new PDO(
        "mysql:host=$host;port=$port;dbname=$database;charset=utf8mb4",
        $username,
        $password
    );

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>