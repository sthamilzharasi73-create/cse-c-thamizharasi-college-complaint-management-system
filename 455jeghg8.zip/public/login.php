<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Student Login | CampusCare</title>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        body {
            min-height: 100vh;
            background: linear-gradient(135deg, #eef2ff, #dbeafe);
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .login-box {
            width: 100%;
            max-width: 420px;
            padding: 35px;
            background: white;
            border-radius: 18px;
            box-shadow: 0 10px 30px #00000015;
        }

        .logo {
            text-align: center;
            color: #4338ca;
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 12px;
        }

        h2 {
            text-align: center;
            margin-bottom: 10px;
            color: #172033;
        }

        .subtitle {
            text-align: center;
            color: #64748b;
            font-size: 14px;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
            font-size: 14px;
        }

        input {
            width: 100%;
            padding: 13px;
            margin-bottom: 18px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            font-size: 15px;
        }

        input:focus {
            outline: none;
            border-color: #4338ca;
        }

        button {
            width: 100%;
            padding: 14px;
            background: #4338ca;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        button:hover {
            background: #3730a3;
        }

        .footer {
            margin-top: 22px;
            text-align: center;
            line-height: 2;
            font-size: 14px;
            color: #64748b;
        }

        a {
            color: #4338ca;
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</head>

<body>

    <div class="login-box">

        <div class="logo">CampusCare</div>

        <h2>Student Login</h2>

        <p class="subtitle">
            Welcome back! Please enter your details.
        </p>

        <form action="dashboard.php" method="GET">

            <label for="email">Email Address</label>
            <input
                type="email"
                id="email"
                name="email"
                placeholder="Enter your email"
                required
            >

            <label for="password">Password</label>
            <input
                type="password"
                id="password"
                name="password"
                placeholder="Enter your password"
                required
            >

            <button type="submit">Login</button>

        </form>

        <div class="footer">
            Don't have an account?
            <a href="register.php">Register here</a>

            <br>

            <a href="index.php">← Back to Home</a>
        </div>

    </div>

</body>
</html>