document.addEventListener("DOMContentLoaded", function () {

    const forms = document.querySelectorAll("form");

    forms.forEach(function (form) {

        form.addEventListener("submit", function (event) {

            const inputs = form.querySelectorAll("input, textarea, select");

            let valid = true;

            inputs.forEach(function (input) {

                if (input.hasAttribute("required") && input.value.trim() === "") {

                    valid = false;

                    input.style.border = "2px solid red";

                } else {

                    input.style.border = "";

                }

            });

            if (!valid) {

                event.preventDefault();

                alert("Please fill all required fields.");

            }

        });

    });

});