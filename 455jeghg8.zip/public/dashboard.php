<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard | CampusCare</title>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f1f5f9;
            color: #1e293b;
        }

        header {
            background: #4338ca;
            color: white;
            padding: 22px 7%;
        }

        header h1 {
            font-size: 26px;
        }

        header p {
            margin-top: 7px;
            color: #e0e7ff;
        }

        .container {
            width: 90%;
            max-width: 1000px;
            margin: 35px auto;
        }

        .welcome {
            background: white;
            padding: 30px;
            border-radius: 14px;
            box-shadow: 0 4px 15px #0000000d;
            margin-bottom: 25px;
        }

        .welcome h2 {
            margin-bottom: 12px;
            color: #4338ca;
        }

        .welcome p {
            color: #64748b;
            line-height: 1.7;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
        }

        .card {
            background: white;
            padding: 25px;
            border-radius: 14px;
            box-shadow: 0 4px 15px #0000000d;
        }

        .card h3 {
            margin-bottom: 12px;
        }

        .card p {
            color: #64748b;
            line-height: 1.6;
            margin-bottom: 20px;
        }

        .btn {
            display: inline-block;
            background: #4338ca;
            color: white;
            padding: 12px 18px;
            text-decoration: none;
            border-radius: 8px;
        }

        .btn:hover {
            background: #3730a3;
        }

        .logout {
            display: inline-block;
            margin-top: 25px;
            color: #4338ca;
            text-decoration: none;
            font-weight: bold;
        }

        footer {
            text-align: center;
            padding: 25px;
            color: #64748b;
        }
    </style>
</head>

<body>

<header>
    <h1>CampusCare</h1>
    <p>Student Dashboard</p>
</header>

<div class="container">

    <section class="welcome">
        <h2>Welcome, Student!</h2>
        <p>
            Welcome to your College Complaint Management System.
            You can submit a complaint and check its status here.
        </p>
    </section>

    <section class="cards">

        <div class="card">
            <h3>Submit Complaint</h3>
            <p>Report an issue to your college administration.</p>
            <a class="btn" href="complaint.php">Submit Complaint</a>
        </div>

        <div class="card">
            <h3>My Complaints</h3>
            <p>View the complaints you have submitted.</p>
            <a class="btn" href="my_complaints.php">View Complaints</a>
        </div>

    </section>

    <a class="logout" href="index.php">← Back to Home</a>

</div>

<footer>
    CampusCare - College Complaint Management System
</footer>

</body>
</html>