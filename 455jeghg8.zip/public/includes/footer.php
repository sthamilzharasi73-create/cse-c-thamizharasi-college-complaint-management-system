</main>

<footer class="main-footer">
    <div class="footer-container">
        <p>&copy; <?php echo date("Y"); ?> CampusCare</p>
        <p>College Complaint Management System</p>
    </div>
</footer>

</body>
</html>