<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CampusCare - College Complaint Management System</title>
    <link rel="stylesheet" href="/css/style.css">
</head>

<body>

<header class="main-header">
    <div class="header-container">
        <div class="logo">
            <span>CC</span>
            <div>
                <h2>CampusCare</h2>
                <p>College Complaint Management System</p>
            </div>
        </div>

        <nav>
            <a href="/index.php">Home</a>

            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="/dashboard.php">Dashboard</a>
                <a href="/logout.php">Logout</a>
            <?php else: ?>
                <a href="/login.php">Login</a>
                <a href="/register.php">Register</a>
            <?php endif; ?>
        </nav>
    </div>
</header>

<main class="page-content">