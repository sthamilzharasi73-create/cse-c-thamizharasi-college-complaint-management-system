<?php
session_start();

require_once "config/database.php";

// User login check
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $user_id = $_SESSION['user_id'];

    $category = trim($_POST['category'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $priority = trim($_POST['priority'] ?? '');

    // Validate fields
    if ($category === '' || $subject === '' || $description === '' || $priority === '') {
        $_SESSION['error'] = "Please fill all fields.";
        header("Location: complaint.php");
        exit();
    }

    // Generate Complaint Reference ID
    $reference_id = "CC" . date("YmdHis") . rand(100, 999);

    try {

        $sql = "INSERT INTO complaints
                (user_id, reference_id, category, subject, description, priority, status, admin_response, created_at)
                VALUES
                (:user_id, :reference_id, :category, :subject, :description, :priority, 'Pending', '', NOW())";

        $stmt = $conn->prepare($sql);

        $stmt->execute([
            ':user_id' => $user_id,
            ':reference_id' => $reference_id,
            ':category' => $category,
            ':subject' => $subject,
            ':description' => $description,
            ':priority' => $priority
        ]);

        $_SESSION['success'] = "Complaint submitted successfully! Reference ID: " . $reference_id;

        header("Location: dashboard.php");
        exit();

    } catch (PDOException $e) {

        $_SESSION['error'] = "Unable to submit complaint. Please try again.";

        header("Location: complaint.php");
        exit();
    }
}
?>