<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>CampusCare | College Complaint Management</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f5f7ff;
            color: #172033;
        }

        header {
            background: #ffffff;
            padding: 20px 7%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            box-shadow: 0 2px 12px #00000010;
        }

        .logo {
            font-size: 25px;
            font-weight: bold;
            color: #4338ca;
        }

        nav {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
        }

        nav a {
            text-decoration: none;
            padding: 11px 18px;
            border-radius: 8px;
            font-weight: bold;
            color: #4338ca;
        }

        nav a.register {
            background: #4338ca;
            color: white;
        }

        nav a:hover {
            opacity: 0.8;
        }

        .hero {
            min-height: 75vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 60px 20px;
        }

        .hero h1 {
            font-size: clamp(32px, 5vw, 52px);
            max-width: 800px;
            line-height: 1.2;
            margin-bottom: 20px;
        }

        .hero h1 span {
            color: #4338ca;
        }

        .hero p {
            max-width: 650px;
            color: #64748b;
            font-size: 17px;
            line-height: 1.8;
            margin-bottom: 30px;
        }

        .buttons {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 15px;
        }

        .btn {
            display: inline-block;
            padding: 15px 25px;
            border-radius: 9px;
            text-decoration: none;
            font-weight: bold;
            background: #4338ca;
            color: white;
        }

        .btn.secondary {
            background: white;
            color: #4338ca;
            border: 1px solid #4338ca;
        }

        .features {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            padding: 20px 7% 60px;
        }

        .feature {
            background: white;
            padding: 25px;
            border-radius: 14px;
            width: 280px;
            box-shadow: 0 5px 20px #00000008;
        }

        .feature h3 {
            color: #4338ca;
            margin-bottom: 12px;
        }

        .feature p {
            color: #64748b;
            line-height: 1.7;
        }

        footer {
            padding: 22px;
            text-align: center;
            color: #64748b;
            background: white;
        }
    </style>
</head>

<body>

<header>
    <div class="logo">CampusCare</div>

    <nav>
        <a href="index.php">Home</a>
        <a href="login.php">Login</a>
        <a href="register.php" class="register">Student Register</a>
    </nav>
</header>

<section class="hero">
    <h1>College Complaints, <span>Made Simple.</span></h1>

    <p>
        Welcome to CampusCare. Register your account, submit college
        complaints, and track their status through one simple system.
    </p>

    <div class="buttons">
        <a class="btn" href="register.php">Get Started — Register</a>
        <a class="btn secondary" href="login.php">Student Login</a>
    </div>
</section>

<section class="features">
    <div class="feature">
        <h3>Submit Complaints</h3>
        <p>Send your college-related issues to the administration.</p>
    </div>

    <div class="feature">
        <h3>Track Status</h3>
        <p>Check the progress of complaints you have submitted.</p>
    </div>

    <div class="feature">
        <h3>Easy to Use</h3>
        <p>Access your complaint information through one platform.</p>
    </div>
</section>

<footer>
    &copy; <?php echo date("Y"); ?> CampusCare — College Complaint Management System
</footer>

</body>
</html>