<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Complaint | CampusCare</title>

    <style>
        * {
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            margin: 0;
            background: #f1f5f9;
            padding: 25px;
        }

        .container {
            max-width: 600px;
            margin: 35px auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 20px #00000012;
        }

        h1 {
            color: #4338ca;
            text-align: center;
        }

        p {
            color: #64748b;
            text-align: center;
        }

        label {
            display: block;
            margin-top: 18px;
            margin-bottom: 7px;
            font-weight: bold;
        }

        input, select, textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            font-size: 15px;
        }

        textarea {
            min-height: 120px;
            resize: vertical;
        }

        button, .back {
            display: inline-block;
            margin-top: 20px;
            padding: 13px 18px;
            border: none;
            border-radius: 8px;
            background: #4338ca;
            color: white;
            text-decoration: none;
            cursor: pointer;
        }

        .back {
            background: #64748b;
            margin-left: 8px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Submit Complaint</h1>
        <p>Tell us about your college-related issue.</p>

        <form action="my_complaints.php" method="get">
            <label for="title">Complaint Title</label>
            <input type="text" id="title" name="title"
                   placeholder="Enter complaint title" required>

            <label for="category">Category</label>
            <select id="category" name="category" required>
                <option value="">Select Category</option>
                <option value="Classroom">Classroom</option>
                <option value="Hostel">Hostel</option>
                <option value="Library">Library</option>
                <option value="Transport">Transport</option>
                <option value="Canteen">Canteen</option>
                <option value="Other">Other</option>
            </select>

            <label for="description">Description</label>
            <textarea id="description" name="description"
                      placeholder="Describe your complaint"
                      required></textarea>

            <button type="submit">Submit Complaint</button>
            <a href="dashboard.php" class="back">Back</a>
        </form>
    </div>
</body>
</html>